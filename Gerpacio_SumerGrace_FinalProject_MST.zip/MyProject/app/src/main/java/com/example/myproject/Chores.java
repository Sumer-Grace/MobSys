package com.example.myproject;

import android.animation.LayoutTransition;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DatabaseReference;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

public class Chores extends AppCompatActivity {

    private static final int REQUEST_ADD_TASK = 1;
    private LinearLayout taskContainer;
    private TextView dateText;
    private ImageView todayImage;

    private Map<String, List<Task>> tasksByDate = new HashMap<>();
    private List<String> sortedTaskDates = new ArrayList<>();


    private int currentDateIndex = -1;

    private final SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
    private final SimpleDateFormat displayDateFormat = new SimpleDateFormat("EEE, MMM d", Locale.ENGLISH);

    private DatabaseReference userRef;
    private static class Task {
        String title;
        String emoji;
        String taskType;
        String date;
        String time;

        public Task() {}

        Task(String title, String emoji, String taskType, String date, String time) {
            this.title = title;
            this.emoji = emoji;
            this.taskType = taskType;
            this.date = date;
            this.time = time;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_chores);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        taskContainer = findViewById(R.id.taskContainer);
        dateText = findViewById(R.id.dateText);
        todayImage = findViewById(R.id.today);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> {
            Intent intent = new Intent(Chores.this, AddTask.class);
            startActivityForResult(intent, REQUEST_ADD_TASK);
        });


        findViewById(R.id.prev).setOnClickListener(v -> {
            if (currentDateIndex > 0) {
                currentDateIndex--;
                updateTasksForCurrentDate();
            }
        });


        findViewById(R.id.today).setOnClickListener(v -> {
            animateTodayIcon();
            String todayStr = getTodayDateString();
            currentDateIndex = findClosestDateIndex(todayStr);
            updateTasksForCurrentDate();
        });


        findViewById(R.id.next).setOnClickListener(v -> {
            if (currentDateIndex < sortedTaskDates.size() - 1) {
                currentDateIndex++;
                updateTasksForCurrentDate();
            }
        });


        updateTasksForCurrentDate();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_ADD_TASK && resultCode == RESULT_OK && data != null) {
            String title = data.getStringExtra("title");
            String emoji = data.getStringExtra("emoji");
            String taskType = data.getStringExtra("taskType");
            String date = data.getStringExtra("date"); // Expect yyyy-MM-dd
            String time = data.getStringExtra("time");

            Task newTask = new Task(title, emoji, taskType, date, time);

            if (!tasksByDate.containsKey(date)) {
                tasksByDate.put(date, new ArrayList<>());
                sortedTaskDates.add(date);
                Collections.sort(sortedTaskDates);
            }

            tasksByDate.get(date).add(newTask);


            currentDateIndex = sortedTaskDates.indexOf(date);

            updateTasksForCurrentDate();
        }
    }

    private void updateTasksForCurrentDate() {
        taskContainer.removeAllViews();

        if (currentDateIndex == -1 || sortedTaskDates.isEmpty()) {
            dateText.setText("No tasks");
            return;
        }

        String currentDate = sortedTaskDates.get(currentDateIndex);
        String formattedDate = formatDisplayDate(currentDate);
        dateText.setText(formattedDate);

        List<Task> tasks = tasksByDate.get(currentDate);
        if (tasks != null) {
            for (Task task : tasks) {
                addTaskToUI(task.title, task.emoji, task.taskType, task.date, task.time);
            }
        }
    }

    private String formatDisplayDate(String dateStr) {
        try {
            Date date = inputDateFormat.parse(dateStr);
            return displayDateFormat.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return dateStr;
        }
    }

    private String getTodayDateString() {
        Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Manila"));
        return inputDateFormat.format(cal.getTime());
    }

    private int findClosestDateIndex(String targetDate) {
        if (sortedTaskDates.isEmpty()) return -1;

        for (int i = 0; i < sortedTaskDates.size(); i++) {
            if (sortedTaskDates.get(i).equals(targetDate)) {
                return i;
            }
            if (sortedTaskDates.get(i).compareTo(targetDate) > 0) {
                return i > 0 ? i - 1 : 0;
            }
        }
        return sortedTaskDates.size() - 1;
    }

    private void animateTodayIcon() {
        todayImage.animate().alpha(0f).setDuration(150).withEndAction(() -> {
            todayImage.animate().alpha(1f).setDuration(150).start();
        }).start();
    }

    private void addTaskToUI(String title, String emoji, String taskType, String date, String time) {
        MaterialCardView cardView = new MaterialCardView(this);
        cardView.setCardElevation(8f);
        cardView.setRadius(16f);
        cardView.setUseCompatPadding(true);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, 24);
        cardView.setLayoutParams(cardParams);

        LinearLayout taskLayout = new LinearLayout(this);
        taskLayout.setOrientation(LinearLayout.VERTICAL);
        taskLayout.setPadding(32, 32, 32, 32);
        taskLayout.setBackgroundColor(getResources().getColor(android.R.color.white));
        taskLayout.setLayoutTransition(new LayoutTransition());

        TextView titleView = new TextView(this);
        titleView.setText(title + " " + emoji);
        titleView.setTextSize(20);
        titleView.setTextColor(getResources().getColor(android.R.color.black));
        titleView.setTypeface(null, Typeface.BOLD);
        titleView.setPadding(0, 0, 0, 16);
        titleView.setClickable(true);
        titleView.setFocusable(true);

        TextView detailsView = new TextView(this);
        detailsView.setText(taskType + "\n" + date + " at " + time);
        detailsView.setTextSize(16);
        detailsView.setTextColor(getResources().getColor(android.R.color.darker_gray));
        detailsView.setVisibility(TextView.GONE);

        View divider = new View(this);
        divider.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 2));
        divider.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));
        divider.setVisibility(View.GONE);

        titleView.setOnClickListener(v -> {
            if (detailsView.getVisibility() == View.VISIBLE) {
                detailsView.setVisibility(View.GONE);
                divider.setVisibility(View.GONE);
            } else {
                detailsView.setVisibility(View.VISIBLE);
                divider.setVisibility(View.VISIBLE);
            }
        });

        taskLayout.addView(titleView);
        taskLayout.addView(divider);
        taskLayout.addView(detailsView);

        cardView.addView(taskLayout);
        taskContainer.addView(cardView);
    }
}