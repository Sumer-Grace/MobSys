package com.example.myproject;

public class Task {
    private String title;
    private String emoji;
    private String date;
    private String time;
    private String taskType;

    public Task() {

    }

    public Task(String title, String emoji, String date, String time, String taskType) {
        this.title = title;
        this.emoji = emoji;
        this.date = date;
        this.time = time;
        this.taskType = taskType;
    }


    public String getTitle() { return title; }
    public String getEmoji() { return emoji; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public String getTaskType() { return taskType; }

    public void setTitle(String title) { this.title = title; }
    public void setEmoji(String emoji) { this.emoji = emoji; }
    public void setDate(String date) { this.date = date; }
    public void setTime(String time) { this.time = time; }
    public void setTaskType(String taskType) { this.taskType = taskType; }
}

