package com.example.myproject;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ActivateEmail extends AppCompatActivity {

    ImageView arrow;
    TextView emailDisplay, dateDisplay;
    Button btnCalendar;
    Button btnChores;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_activate_email);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        emailDisplay = findViewById(R.id.emaill);
        dateDisplay = findViewById(R.id.chores);
        btnCalendar = findViewById(R.id.btn_calendar);
        btnChores = findViewById(R.id.btn_chores);

        String currentDate = new SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(new Date());
        dateDisplay.setText(currentDate);

        String email = getIntent().getStringExtra("user_email");
        if (email != null && !email.isEmpty()) {
            emailDisplay.setText(email);
        } else {
            emailDisplay.setText("No email provided");
        }

        btnCalendar.setOnClickListener(view -> {
            Intent intent = new Intent(ActivateEmail.this, CalendarActivity.class);
            startActivity(intent);
            Toast.makeText(getApplicationContext(), "Opening Calendar", Toast.LENGTH_SHORT).show();
        });

        btnChores.setOnClickListener(view -> {
            Intent intent = new Intent(ActivateEmail.this, Chores.class);
            startActivity(intent);
            Toast.makeText(getApplicationContext(), "Opening Chores", Toast.LENGTH_SHORT).show();
        });
    }
}