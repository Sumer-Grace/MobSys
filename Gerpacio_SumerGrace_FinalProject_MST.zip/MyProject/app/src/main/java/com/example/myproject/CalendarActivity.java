package com.example.myproject;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;



public class CalendarActivity extends AppCompatActivity {

    TextView tvMonthYear, selectedDateTextView;
    GridLayout calendarGrid;
    Calendar calendar;
    String selectedDate = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        tvMonthYear = findViewById(R.id.tvMonthYear);
        calendarGrid = findViewById(R.id.calendarGrid);
        calendar = Calendar.getInstance();
        selectedDateTextView = findViewById(R.id.selectedDateTextView);

        Button btnPrev = findViewById(R.id.btnPrev);
        Button btnToday = findViewById(R.id.btnToday);
        Button btnNext = findViewById(R.id.btnNext);

        btnPrev.setOnClickListener(v -> {
            calendar.add(Calendar.MONTH, -1);
            updateCalendar();
        });

        btnNext.setOnClickListener(v -> {
            calendar.add(Calendar.MONTH, 1);
            updateCalendar();
        });

        btnToday.setOnClickListener(v -> {
            calendar = Calendar.getInstance();
            updateCalendar();
        });

        updateCalendar();
    }

    private void updateCalendar() {
        int currentMonth = calendar.get(Calendar.MONTH);
        int currentYear = calendar.get(Calendar.YEAR);
        int today = Calendar.getInstance().get(Calendar.DAY_OF_MONTH);


        boolean isCurrentMonth = calendar.get(Calendar.YEAR) == Calendar.getInstance().get(Calendar.YEAR)
                && calendar.get(Calendar.MONTH) == Calendar.getInstance().get(Calendar.MONTH);

        tvMonthYear.setText(getMonthName(currentMonth) + " " + currentYear);

        calendar.set(Calendar.DAY_OF_MONTH, 1);
        int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        int totalDays = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        calendarGrid.removeAllViews();


        for (int i = 1; i < firstDayOfWeek; i++) {
            calendarGrid.addView(createEmptyCell());
        }


        for (int day = 1; day <= totalDays; day++) {
            TextView cell = createCell(String.valueOf(day));
            if (isCurrentMonth && day == today) {
                cell.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);
                cell.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
            }
            calendarGrid.addView(cell);
        }
    }

    private TextView createEmptyCell() {
        TextView textView = new TextView(this);
        textView.setLayoutParams(new GridLayout.LayoutParams());
        textView.setText("");
        return textView;
    }

    private TextView createCell(String text) {
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setGravity(Gravity.CENTER);
        textView.setTextSize(16);
        textView.setPadding(10, 10, 10, 10);


        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = 0;
        params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        textView.setLayoutParams(params);


        textView.setOnClickListener(v -> {

            for (int i = 0; i < calendarGrid.getChildCount(); i++) {
                TextView cell = (TextView) calendarGrid.getChildAt(i);
                if (cell != null) {
                    cell.setBackgroundColor(getResources().getColor(android.R.color.transparent));
                    cell.setTextColor(getResources().getColor(android.R.color.black));
                }
            }


            textView.setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
            textView.setTextColor(getResources().getColor(android.R.color.white));


            selectedDate = textView.getText().toString();
            selectedDateTextView.setText("Selected Date: " + selectedDate);
        });

        return textView;
    }

    private String getMonthName(int month) {
        String[] months = {
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
        };
        return months[month];
    }
}

