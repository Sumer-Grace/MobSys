package com.example.myproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


public class CreateAccount extends AppCompatActivity {

    Button btn_create;
    TextView email;
    EditText name, password, confirmedPassword, number, day, month, year;
    CheckBox checkService;
    Spinner daySpinner, monthSpinner, yearSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_create_account);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // Pagkuha ng data mula sa UI fields
        btn_create = findViewById(R.id.btn_create);
        email = findViewById(R.id.email);
        name = findViewById(R.id.name);
        password = findViewById(R.id.password);
        confirmedPassword = findViewById(R.id.confirmedPassword);
        number = findViewById(R.id.number);
        daySpinner = findViewById(R.id.spinner_day);
        monthSpinner = findViewById(R.id.spinner_month);
        yearSpinner = findViewById(R.id.spinner_year);
        checkService = findViewById(R.id.checkservice);

        // Kinuha ang email na ipinasa mula sa ibang activity (MainActivity)
        String receivedEmail = getIntent().getStringExtra("user_email");
        if (receivedEmail != null) {
            email.setText(receivedEmail);
        }

        setupSpinners();

        btn_create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameInput = name.getText().toString().trim();
                String emailInput = email.getText().toString().trim();
                String passInput = password.getText().toString();
                String confirmInput = confirmedPassword.getText().toString();
                String numberInput = number.getText().toString().trim();
                String dayInput = daySpinner.getSelectedItem().toString();
                String monthInput = monthSpinner.getSelectedItem().toString();
                String yearInput = yearSpinner.getSelectedItem().toString();

                // Validation para sa mga input tulad ng pangalan, password, number, at checkbox
                if (nameInput.isEmpty()) {
                    name.setError("Name is required");
                    name.requestFocus();
                    return;
                }

                if (passInput.isEmpty()) {
                    password.setError("Password is required");
                    password.requestFocus();
                    return;
                }

                // Password strength validation
                if (!passInput.matches("^(?=.*[A-Z])(?=.*\\d)[A-Za-z\\d]{8,}$")) {
                    password.setError("Password must be at least 8 characters, include 1 uppercase letter and 1 number");
                    password.requestFocus();
                    return;
                }

                if (confirmInput.isEmpty()) {
                    confirmedPassword.setError("Confirm your password");
                    confirmedPassword.requestFocus();
                    return;
                }

                if (!passInput.equals(confirmInput)) {
                    confirmedPassword.setError("Passwords do not match");
                    confirmedPassword.requestFocus();
                    return;
                }

                if (numberInput.isEmpty()) {
                    number.setError("Number is required");
                    number.requestFocus();
                    return;
                }

                if (!numberInput.matches("\\d{11}")) {
                    number.setError("Phone number must be exactly 11 digits");
                    number.requestFocus();
                    return;
                }

                if (!checkService.isChecked()) {
                    Toast.makeText(getApplicationContext(), "You must agree to the Terms of Service", Toast.LENGTH_SHORT).show();
                    return;
                }


                try {
                    int dayInt = Integer.parseInt(dayInput);
                    int monthInt = Integer.parseInt(monthInput);
                    int yearInt = Integer.parseInt(yearInput);

                    // Pagsusuri kung 18+ years old ang user base sa birthday inputs
                    Calendar dob = Calendar.getInstance();
                    dob.set(yearInt, monthInt - 1, dayInt);

                    Calendar today = Calendar.getInstance();
                    int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

                    if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
                        age--;
                    }

                    if (age < 18) {
                        Toast.makeText(getApplicationContext(), "You must be at least 18 years old to register", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    String birthday = dayInput + "/" + monthInput + "/" + yearInput;

                    Users user = new Users(nameInput, emailInput, passInput, numberInput, birthday);

                    String emailKey = emailInput.replace(".", ",");
                    DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("users");
                    dbRef.child(emailKey).setValue(user).addOnSuccessListener(unused -> {
                        SharedPreferences prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putString("user_email", emailInput);
                        editor.apply();

                        Toast.makeText(getApplicationContext(), "Account Created! Input again the email", Toast.LENGTH_SHORT).show();

                    Intent deviceIntent = new Intent(CreateAccount.this, MainActivity.class);
                    deviceIntent.putExtra("user_name", nameInput);
                        startActivity(deviceIntent);
                        finish();
                    }).addOnFailureListener(e -> {
                        Toast.makeText(getApplicationContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });



                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Please select valid birthday details", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void setupSpinners() {
        List<String> days = new ArrayList<>();
        days.add("Day");
        for (int i = 1; i <= 31; i++) {
            days.add(String.valueOf(i));
        }

        List<String> months = new ArrayList<>();
        months.add("Month");
        for (int i = 1; i <= 12; i++) {
            months.add(String.valueOf(i));
        }

        List<String> years = new ArrayList<>();
        years.add("Year");
        for (int i = 1999; i <= 2025; i++) {
            years.add(String.valueOf(i));
        }

        daySpinner.setAdapter(getHintedAdapter(days));
        monthSpinner.setAdapter(getHintedAdapter(months));
        yearSpinner.setAdapter(getHintedAdapter(years));
    }
    private ArrayAdapter<String> getHintedAdapter(List<String> items) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            @Override
            public boolean isEnabled(int position) {
                return position != 0;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                TextView tv = (TextView) view;
                if (position == 0) {
                    tv.setTextColor(Color.GRAY);
                } else {
                    tv.setTextColor(Color.BLACK);
                }
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return adapter;
    }
}