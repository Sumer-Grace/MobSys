package com.example.myproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Device extends AppCompatActivity {
    ImageView notif;
    ImageView acc;
    TextView emailText;
    Button activate;

    String name, email, password, number, birthday;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_device);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        notif = findViewById(R.id.notif);
        acc = findViewById(R.id.acc);
        activate = findViewById(R.id.activate);
        emailText = findViewById(R.id.com);

        SharedPreferences preferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        if (getIntent().hasExtra("user_email")) {
            email = getIntent().getStringExtra("user_email");
            name = getIntent().getStringExtra("user_name");
            password = getIntent().getStringExtra("user_password");
            number = getIntent().getStringExtra("user_number");
            birthday = getIntent().getStringExtra("user_birthday");

            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("email", email);
            editor.putString("name", name);
            editor.putString("password", password);
            editor.putString("number", number);
            editor.putString("birthday", birthday);
            editor.apply();
        } else {
            // Load from SharedPreferences if no intent data is found
            email = preferences.getString("email", "");
            name = preferences.getString("name", "");
            password = preferences.getString("password", "");
            number = preferences.getString("number", "");
            birthday = preferences.getString("birthday", "");
        }

        emailText.setText(email);

        String receivedEmail = getIntent().getStringExtra("user_email");
        emailText.setText(receivedEmail);

            notif.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(Device.this, Notification.class);
                    startActivity(intent);

                    Toast.makeText(getApplicationContext(), "Notification", Toast.LENGTH_SHORT).show();
                }
            });
        acc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToAccount = new Intent(Device.this, Account.class);
                goToAccount.putExtra("user_name", name);
                goToAccount.putExtra("user_email", email);
                goToAccount.putExtra("user_password", password);
                goToAccount.putExtra("user_number", number);
                goToAccount.putExtra("user_birthday", birthday);
                startActivity(goToAccount);
            }
        });
        activate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Device.this, ActivateEmail.class);
                String currentEmail = getIntent().getStringExtra("user_email");
                intent.putExtra("user_email", currentEmail); // Pass the email
                startActivity(intent);

                Toast.makeText(getApplicationContext(), "Activated", Toast.LENGTH_SHORT).show();
            }
        });
        }
    }
