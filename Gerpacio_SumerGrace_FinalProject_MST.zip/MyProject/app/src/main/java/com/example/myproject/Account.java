package com.example.myproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Account extends AppCompatActivity {

    TextView nameText, emailText, passwordText, numberText, birthdayText, Textnotifications, Textlogout, Textdelete;
    SharedPreferences prefs;
    String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_account);

        nameText = findViewById(R.id.name);
        emailText = findViewById(R.id.email);
        passwordText = findViewById(R.id.password);
        numberText = findViewById(R.id.number);
        birthdayText = findViewById(R.id.birthday);
        Textnotifications = findViewById(R.id.notif);
        Textlogout = findViewById(R.id.logout);
        Textdelete = findViewById(R.id.delete);

        prefs = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        email = getIntent().getStringExtra("user_email");

        if (email != null) {
            fetchUserInfo(email);
        } else {
            Toast.makeText(this, "No user email provided", Toast.LENGTH_SHORT).show();
        }

        Textlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                logoutUser();
            }
        });

        Textdelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirmDeleteAccount();
            }
        });
    }

    private void fetchUserInfo(String email) {
        String emailKey = email.replace(".", ",");

        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("users")
                .child(emailKey);
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Users user = snapshot.getValue(Users.class);
                    if (user != null) {
                        nameText.setText(user.getName());
                        emailText.setText(user.getEmail());
                        passwordText.setText(user.getPassword());
                        numberText.setText(user.getNumber());
                        birthdayText.setText(user.getBirthday());
                    }
                } else {
                    Toast.makeText(Account.this, "User not found in database", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Account.this, "Error loading user data", Toast.LENGTH_SHORT).show();
            }
        });
    }

        private void confirmDeleteAccount() {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Delete Account")
                    .setMessage("Are you sure you want to delete your account permanently?")
                    .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            deleteUserFromDatabase();
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }

    private void deleteUserFromDatabase() {
        if (email == null) return;

        String emailKey = email.replace(".", ",");

        DatabaseReference ref = FirebaseDatabase.getInstance()
                .getReference("users")
                .child(emailKey);

        ref.removeValue().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(Account.this, "Account deleted successfully", Toast.LENGTH_SHORT).show();
                logoutUser();
            } else {
                Toast.makeText(Account.this, "Failed to delete account", Toast.LENGTH_SHORT).show();
            }
        });
    }

        private void logoutUser() {
            SharedPreferences.Editor editor = prefs.edit();
            editor.clear();
            editor.apply();

            Intent intent = new Intent(Account.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }
}


