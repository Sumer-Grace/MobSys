package com.example.myproject;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.widget.*;



public class AddTask extends AppCompatActivity {

    private TextView tvDate, tvTime;
    private Button btnAdd;
    private EditText etTitle, etEmoji;
    private RadioGroup radioTaskType;

    private Calendar selectedCalendar = Calendar.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_task);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etTitle = findViewById(R.id.title);
        etEmoji = findViewById(R.id.emoji);
        tvDate = findViewById(R.id.tvDate);
        tvTime = findViewById(R.id.tvTime);
        btnAdd = findViewById(R.id.btnAdd);
        radioTaskType = findViewById(R.id.radioTaskType);


        tvDate.setOnClickListener(view -> showDatePicker());


        tvTime.setOnClickListener(view -> showTimePicker());


        btnAdd.setOnClickListener(view -> {
            String title = etTitle.getText().toString().trim();
            String emoji = etEmoji.getText().toString().trim();

            int selectedTypeId = radioTaskType.getCheckedRadioButtonId();
            if (selectedTypeId == -1) {
                Toast.makeText(this, "Please select a task type", Toast.LENGTH_SHORT).show();
                return;
            }
            String taskType = ((RadioButton) findViewById(selectedTypeId)).getText().toString();

            String date = tvDate.getText().toString();
            String time = tvTime.getText().toString();
            if (title.isEmpty() || date.isEmpty() || time.isEmpty()) {
                Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent resultIntent = new Intent();
            resultIntent.putExtra("title", title);
            resultIntent.putExtra("emoji", emoji);
            resultIntent.putExtra("taskType", taskType);
            resultIntent.putExtra("date", date);
            resultIntent.putExtra("time", time);

            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }

    private void showDatePicker() {
        int year = selectedCalendar.get(Calendar.YEAR);
        int month = selectedCalendar.get(Calendar.MONTH);
        int day = selectedCalendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, (view, y, m, d) -> {
            selectedCalendar.set(Calendar.YEAR, y);
            selectedCalendar.set(Calendar.MONTH, m);
            selectedCalendar.set(Calendar.DAY_OF_MONTH, d);

            tvDate.setText("Date: " + android.text.format.DateFormat.format("EEE, MMM d", selectedCalendar));
        }, year, month, day);

        datePickerDialog.show();
    }

    private void showTimePicker() {
        int hour = selectedCalendar.get(Calendar.HOUR_OF_DAY);
        int minute = selectedCalendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this, (view, h, m) -> {
            selectedCalendar.set(Calendar.HOUR_OF_DAY, h);
            selectedCalendar.set(Calendar.MINUTE, m);

            tvTime.setText(String.format("Time: %02d:%02d", h, m));
        }, hour, minute, true);

        timePickerDialog.show();
    }
}

